# importing the multiprocessing module 
import multiprocessing 
import os
import time
def edith(): 
	os.system("python final.py")
def final():  
	time.sleep(2)
	os.system("python edith.py")
if __name__ == "__main__": 

	p1 = multiprocessing.Process(target=edith) 
	p2 = multiprocessing.Process(target=final) 

	p1.start() 
	p2.start() 
	p1.join() 
	p2.join() 

	# both processes finished 
	print("Done!") 		
