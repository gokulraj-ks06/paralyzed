from twilio.rest import Client

account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
auth_token = '226ad212d1b9bd4f255f0572ff7bb3ac'
client = Client(account_sid, auth_token)

call = client.calls.create(
                        url='http://demo.twilio.com/docs/voice.xml',
                        to='+919629687123',
                        from_='+919500634132'
                    )

print(call.sid)
