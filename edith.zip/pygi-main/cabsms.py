from twilio.rest import Client


account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
auth_token = '226ad212d1b9bd4f255f0572ff7bb3ac'
client = Client(account_sid, auth_token)

message = client.messages \
    .create(
         body='Please drive me to'+' Time square '+'from my home,I will pay cash on drop',
         from_='+12188750018',
         to='+919629687123'
     )

print(message.sid)