from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
# DANGER! This is insecure. See http://twil.io/secure
account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
auth_token = '226ad212d1b9bd4f255f0572ff7bb3ac'
client = Client(account_sid, auth_token)

message = client.messages.create(
                              body='Hello there!',
                              from_='whatsapp:+1 415 523 8886 ',
                              to='whatsapp:+91 9629687123'
                          )

print(message.sid)