add 2 movies here,name it as movie1,movie2
