
import eel
import os
import subprocess
import sys
import multiprocessing 
import vlc
import time
import playsound
eel.init('web')
import cv2
import smtplib 
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
def sender(recipients): 

    s = smtplib.SMTP('smtp.gmail.com', 587) 
      
    # start TLS for security 
    s.starttls() 
      
    # Authentication 
    s.login("gokulrajks06@gmail.com", "loveu#3000") 
      
    # message to be sent 

    
    html = "Please book an appoinment at"+" 9 am"
    msg = MIMEMultipart('related')

    msg1= MIMEText(html, "html")
    msg.attach(msg1)


    msg['Subject'] = 'Booking Appoinment'
    msg['From'] = 'gokulrajks06@gmail.com'
    msg['To'] = recipients

    
    html2="Please book an appoinment at"+" 2 pm"
    msg2 = MIMEMultipart('related')
    msg3= MIMEText(html2, "html2")
    msg2.attach(msg3)


      
    msg2['Subject'] = 'Booking Appoinment For Gokulraj'
    msg2['From'] = 'gokulrajks06@gmail.com'
    msg2['To'] = recipients

      
    # sending the mail 
    s.sendmail("gokulrajks@pesu.pes.edu", recipients, msg.as_string()) 
      
    # terminating the session 
    s.quit() 

from pynput.keyboard import Key, Controller
keyboard = Controller()
from twilio.rest import Client
account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
auth_token = '226ad212d1b9bd4f255f0572ff7bb3ac'
client = Client(account_sid, auth_token)
playkey=0  
@eel.expose
def quit():
    print("quit")
    keyboard.press(Key.alt)
    keyboard.press(Key.f4)
    keyboard.release(Key.alt)
    keyboard.release(Key.f4)
    cv2.destroyAllWindows()
    sys.exit()


@eel.expose
def food1():
    message = client.messages \
    .create(
         body='Please bring '+'Medicine1'+' to my home,I will pay cash on delivery',
         from_='+12188750018',
         to='+919629687123'
     )
@eel.expose
def food2():
    message = client.messages \
    .create(
         body='Please bring '+'Medicine2'+' to my home,I will pay cash on delivery',
         from_='+12188750018',
         to='+919629687123'
     )
@eel.expose
def on():
    os.system("python on.py")
@eel.expose
def mail1():
    i="ksgokulraj07@gmail.com"
    print(i)
    sender(i)
    recipients(i)
    s.sendmail("ksgokulraj07@gmail.com",recipients,msg.as_string())
    s.quit()
@eel.expose
def mail2():
    i="ksgokulraj07@gmail.com"
    print(i)
    sender(i)
    recipients(i)
    s.sendmail("ksgokulraj07@gmail.com",recipients,msg2.as_string())
    s.quit()
@eel.expose
def final():
    os.system("python final.py")    
@eel.expose
def off():
    os.system("python off.py")
@eel.expose
def cab1():
    print('cab1')
    os.system("python timesquare.py")
@eel.expose
def cab2():
    print('cab2')
    os.system("python cp.py")
@eel.expose
def movie1():
    os.system("python movie1.py")
@eel.expose

def movie2():
    os.system("python movie2.py")


@eel.expose
def nav():
    print("Opening navigation")


@eel.expose
def call():
    os.system("python call.py")
@eel.expose
def isos():
    os.system("python call.py")
@eel.expose
def song1():
    global playkey
    global player
    if playkey==1:
        player.stop()
        playkey=0
    song="/home/mrstark/edith/music/a.mp3"
    player = vlc.MediaPlayer(song)
    player.play()
    playkey=1
@eel.expose
def stop():
    global playkey
    global player
    if playkey==1:
        player.stop()
        playkey=0
@eel.expose
def song2():
    global playkey
    global player
    if playkey==1:
        player.stop()
        playkey=0
    song="/home/mrstark/edith/music/b.mp3"
    player = vlc.MediaPlayer(song)
    player.play()
    playkey=1
@eel.expose
def song3():
    global playkey
    global player
    if playkey==1:
        player.stop()
        playkey=0
    song="/home/mrstark/edith/music/p.mp3"
    player = vlc.MediaPlayer(song)
    player.play()
    playkey=1
@eel.expose
def game():
    os.system("python game.py")

eel.start('index.html', size=(1000, 600))
