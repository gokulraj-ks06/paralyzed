
function quit() {
	eel.quit()
}
function videocall() {
	eel.videocall()}
function food() {
	eel.food()}
function appoinment() {
	eel.appoinment()}
function on() {
	eel.on()}
function off() {
	eel.off()}
function music() {
	eel.music()
}
function cab1() {
	eel.cab1()
}
function cab2() {
	eel.cab2()
}

function food2() {
	eel.food2()
}
function mail1() {
	eel.mail1()
}

function mail2() {
	eel.maila2()
}

function food1() {
	eel.food1()
}
function movie1() {
	eel.movie1()}
function movie2() {
	eel.movie2()}
function game() {
	eel.game()}
function nav() {
	eel.nav()}
function iot() {
	eel.iot()}
function call() {
	eel.call()}
function isos() {
	eel.isos()}
function song1() {
	eel.song1()}
function stop() {
	eel.stop()}
function song2() {
	eel.song2()}
function song3() {
	eel.song3()}
function game() {
	eel.game()
}
