from scipy.spatial import distance as dist
from imutils.video import VideoStream
from imutils import face_utils
import numpy as np
import playsound
import imutils
import time
import dlib
import cv2
import multiprocessing
import sys       
from pynput.keyboard import Key, Controller
from math import hypot
global a
import pyautogui
keyboarda = Controller()    

def tab():
    while True:
        print("tab")
        keyboarda.press(Key.tab)
        keyboarda.release(Key.tab)   
        time.sleep(3)

def midpoint(p1 ,p2):
    return int((p1.x + p2.x)/2), int((p1.y + p2.y)/2)

FONT_HERSHEY_PLAIN = cv2.FONT_HERSHEY_PLAIN
font=cv2.FONT_HERSHEY_PLAIN
def get_blinking_ratio(eye_points, facial_landmarks):
    left_point = (facial_landmarks.part(eye_points[0]).x, facial_landmarks.part(eye_points[0]).y)
    right_point = (facial_landmarks.part(eye_points[3]).x, facial_landmarks.part(eye_points[3]).y)
    center_top = midpoint(facial_landmarks.part(eye_points[1]), facial_landmarks.part(eye_points[2]))
    center_bottom = midpoint(facial_landmarks.part(eye_points[5]), facial_landmarks.part(eye_points[4]))
    hor_line_lenght = hypot((left_point[0] - right_point[0]), (left_point[1] - right_point[1]))
    ver_line_lenght = hypot((center_top[0] - center_bottom[0]), (center_top[1] - center_bottom[1]))
    if ver_line_lenght!=0:
            ratio = hor_line_lenght / ver_line_lenght
            return ratio

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear
 
c=0
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

cap = cv2.VideoCapture(0)
time.sleep(1.0)
def longblink():
    c=0
    blinking_ratio=0
    while True: 
        _, frame = cap.read()

        frame = imutils.resize(frame, width=450)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rects = detector(gray, 0)
        for rect in rects:
            shape = predictor(gray, rect)
            landmarks=shape
            shape = face_utils.shape_to_np(shape)                
            leftEye = shape[lStart:lEnd]
            rightEye = shape[rStart:rEnd]
            leftEAR = eye_aspect_ratio(leftEye)
            rightEAR = eye_aspect_ratio(rightEye)
            ear = (leftEAR + rightEAR) / 2.0
            leftEyeHull = cv2.convexHull(leftEye)
            rightEyeHull = cv2.convexHull(rightEye)
            cv2.drawContours(frame, [leftEyeHull], -1, (0, 255, 0), 1)
            cv2.drawContours(frame, [rightEyeHull], -1, (0, 255, 0), 1)
            left_eye_ratio = get_blinking_ratio([36, 37, 38, 39, 40, 41], landmarks)
            right_eye_ratio = get_blinking_ratio([42, 43, 44, 45, 46, 47], landmarks)
            if left_eye_ratio!=None and right_eye_ratio !=None:
                blinking_ratio = (left_eye_ratio + right_eye_ratio) / 2
            

            if ear < 0.3:
                c=c+1
                print(c)
                if c>100:
                    print("long blink")
                    pyautogui.press('enter')    
            if ear > 0.31:  
                c=0
            cv2.putText(frame, "EAR: {:.2f}".format(ear), (300, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            if blinking_ratio > 5.7:
                if c<10:
                    cv2.putText(frame, "BLINKING", (50, 150), font, 4, (255, 0, 0))
                    pyautogui.press('space')
     
        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF 
        if key == ord("q"):
            break
            sys.exit()

    cv2.destroyAllWindows()
    cap.release()
#rStart                                                                               t
if __name__ == "__main__": 
    p1 = multiprocessing.Process(target=tab) 
    p2 = multiprocessing.Process(target=longblink) 
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    print("Done!") 
