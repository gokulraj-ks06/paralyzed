add 3 songs here name it as a.mp4,b.mp4,p.mp4
