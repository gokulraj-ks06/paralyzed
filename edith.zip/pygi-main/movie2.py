import sys
import vlc
from easygui import *
import multiprocessing
import sys
import cv2
from pynput import keyboard
import time
from pynput.keyboard import Key, Controller
import subprocess
keyboarda = Controller()
point=0
def on_press(key):
    try:
        pass
    except AttributeError:
        print('special key {0} pressed'.format(key))
def on_release(key):
    if key == keyboard.Key.enter:
        return False



def control():
    with keyboard.Listener(
        on_press=on_press,
        on_release=on_release) as listener:
        listener.join()
    listener = keyboard.Listener(
        on_press=on_press,
        on_release=on_release)
    listener.start()

def media():
    media="/home/mrstark/edith/movie/movie2.mp4" 
    player = vlc.MediaPlayer(media)
    player.video_set_scale(0.3) 
    player.play()
    control()    
    
media()