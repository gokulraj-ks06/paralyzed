import serial

connected = False

ser = serial.Serial("/dev/ttyUSB0", 9600)
c=0
while not connected:
	    serin = ser.read()
	    connected = True
while True:
	ser.write("l")
	print(ser.readline())
	c+=1
	if c>4:
		import os
		os.system("python call.py")
		break
ser.close()
#if serin='1':
#	os.system("python call.py")