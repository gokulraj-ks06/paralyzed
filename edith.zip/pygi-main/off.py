import serial

connected = False

ser = serial.Serial("/dev/ttyUSB0", 9600)

while not connected:
    serin = ser.read()
    connected = True

ser.write("b")
while ser.read() == '1':
    ser.read()
ser.close()