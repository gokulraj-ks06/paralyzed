# EDITH
run final.py in one terminal and edith.py in other


